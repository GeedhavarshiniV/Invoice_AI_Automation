import os
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

def get_gemini_client(vision: bool = False):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY not set in .env file")
    genai.configure(api_key=api_key)
    model_name = "gemini-1.5-flash" if vision else "gemini-1.5-flash"
    return genai.GenerativeModel(model_name)
