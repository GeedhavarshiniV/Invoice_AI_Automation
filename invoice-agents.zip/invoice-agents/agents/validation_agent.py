"""
Validation Agent
----------------
Takes extracted invoice data and runs two layers of checks:
  1. Rule-based (math, required fields, date logic)
  2. AI-based (Gemini flags semantic anomalies)
"""

import json
import re
from datetime import date, datetime
from core.gemini import get_gemini_client


# ── RULE-BASED CHECKS ──────────────────────────────────────────────────────

def validate_invoice(data: dict) -> dict:
    """
    Synchronous rule-based validation.
    Returns a validation report with pass/warn/fail per check.
    """
    checks = []

    # 1. Required fields
    required = ["vendor_name", "invoice_number", "total_amount", "invoice_date"]
    missing = [f for f in required if not data.get(f)]
    if missing:
        checks.append({"rule": "required_fields", "status": "fail",
                        "message": f"Missing required fields: {', '.join(missing)}"})
    else:
        checks.append({"rule": "required_fields", "status": "pass",
                        "message": "All required fields present"})

    # 2. Math check: subtotal + tax ≈ total
    subtotal = data.get("subtotal") or 0
    tax = data.get("tax_amount") or 0
    total = data.get("total_amount") or 0
    discount = data.get("discount") or 0
    expected = round(subtotal + tax - discount, 2)

    if total and subtotal:
        diff = abs(expected - total)
        if diff < 0.02:
            checks.append({"rule": "totals_match", "status": "pass",
                            "message": f"Subtotal + tax = total ✓ (${total})"})
        elif diff < 1.0:
            checks.append({"rule": "totals_match", "status": "warn",
                            "message": f"Minor rounding difference: expected ${expected}, got ${total}"})
        else:
            checks.append({"rule": "totals_match", "status": "fail",
                            "message": f"Total mismatch: expected ${expected} (subtotal+tax), got ${total}"})
    else:
        checks.append({"rule": "totals_match", "status": "warn",
                        "message": "Could not verify totals — subtotal or total missing"})

    # 3. Line items sum
    line_items = data.get("line_items") or []
    if line_items:
        li_total = sum(item.get("amount") or 0 for item in line_items)
        if li_total and subtotal:
            diff = abs(li_total - subtotal)
            if diff < 0.02:
                checks.append({"rule": "line_items_sum", "status": "pass",
                                "message": f"Line items sum to subtotal ✓ (${li_total})"})
            else:
                checks.append({"rule": "line_items_sum", "status": "warn",
                                "message": f"Line items (${li_total}) don't match subtotal (${subtotal})"})

    # 4. Date logic
    inv_date = _parse_date(data.get("invoice_date"))
    due_date = _parse_date(data.get("due_date"))
    today = date.today()

    if inv_date:
        if inv_date > today:
            checks.append({"rule": "invoice_date", "status": "warn",
                            "message": f"Invoice date {inv_date} is in the future"})
        elif (today - inv_date).days > 365:
            checks.append({"rule": "invoice_date", "status": "warn",
                            "message": f"Invoice date is over a year ago — possible old/duplicate"})
        else:
            checks.append({"rule": "invoice_date", "status": "pass",
                            "message": f"Invoice date {inv_date} is valid"})

    if inv_date and due_date:
        if due_date < inv_date:
            checks.append({"rule": "due_date", "status": "fail",
                            "message": "Due date is before invoice date — data error"})
        elif due_date < today:
            checks.append({"rule": "due_date", "status": "warn",
                            "message": f"Invoice is overdue (due {due_date})"})
        else:
            checks.append({"rule": "due_date", "status": "pass",
                            "message": f"Due date {due_date} is valid"})

    # 5. Currency check
    currency = data.get("currency", "").upper()
    known = {"USD", "EUR", "GBP", "INR", "AUD", "CAD", "SGD", "AED", "JPY"}
    if currency in known:
        checks.append({"rule": "currency", "status": "pass",
                        "message": f"Currency {currency} recognised"})
    elif currency:
        checks.append({"rule": "currency", "status": "warn",
                        "message": f"Unknown currency: {currency}"})

    # 6. Confidence score
    conf = data.get("confidence_score", 1.0)
    if conf >= 0.9:
        checks.append({"rule": "ocr_confidence", "status": "pass",
                        "message": f"OCR confidence high ({int(conf*100)}%)"})
    elif conf >= 0.7:
        checks.append({"rule": "ocr_confidence", "status": "warn",
                        "message": f"OCR confidence medium ({int(conf*100)}%) — review recommended"})
    else:
        checks.append({"rule": "ocr_confidence", "status": "fail",
                        "message": f"OCR confidence low ({int(conf*100)}%) — manual re-entry recommended"})

    # Summary
    statuses = [c["status"] for c in checks]
    if "fail" in statuses:
        overall = "fail"
    elif "warn" in statuses:
        overall = "warn"
    else:
        overall = "pass"

    return {
        "overall": overall,
        "checks": checks,
        "summary": {
            "pass": statuses.count("pass"),
            "warn": statuses.count("warn"),
            "fail": statuses.count("fail"),
        },
        "_agent": "validation-rules",
    }


# ── AI-BASED ANOMALY DETECTION ─────────────────────────────────────────────

AI_VALIDATION_PROMPT = """
You are a financial fraud and anomaly detection specialist reviewing an invoice.

Invoice data:
{invoice_json}

Analyse this invoice for:
1. Unusually high or suspicious amounts
2. Vague or generic line item descriptions (e.g. "services", "miscellaneous")
3. Missing vendor contact details that should be present
4. Round numbers that look fabricated
5. Any other red flags a finance team should know about

Return ONLY a JSON object like this:
{{
  "anomalies": [
    {{
      "severity": "high|medium|low",
      "field": "field name or 'general'",
      "message": "clear plain-English explanation"
    }}
  ],
  "risk_score": number from 0 (clean) to 1 (very suspicious),
  "recommendation": "approve|review|reject",
  "ai_notes": "one sentence summary for the finance team"
}}

Return ONLY the JSON object, no markdown.
"""


def ai_validate_invoice(data: dict) -> dict:
    """
    AI-powered anomaly detection via Gemini.
    Runs on top of rule-based validation.
    """
    model = get_gemini_client()
    prompt = AI_VALIDATION_PROMPT.format(invoice_json=json.dumps(data, indent=2))

    try:
        response = model.generate_content(prompt)
        raw = response.text.strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
        result = json.loads(raw)
        result["_agent"] = "validation-ai"
        return {"success": True, "data": result}
    except json.JSONDecodeError:
        return {"success": False, "error": "AI returned non-JSON", "raw": response.text[:300]}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _parse_date(val) -> date | None:
    if not val:
        return None
    try:
        return datetime.strptime(str(val), "%Y-%m-%d").date()
    except ValueError:
        return None
