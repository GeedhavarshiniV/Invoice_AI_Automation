"""
OCR Extraction Agent
--------------------
Accepts a PDF or image file, sends it to Gemini Vision,
and returns structured invoice fields as JSON.
"""

import io
import json
import base64
import re
from PIL import Image
import google.generativeai as genai
from core.gemini import get_gemini_client

EXTRACTION_PROMPT = """
You are an invoice data extraction specialist. Carefully read this invoice image and extract ALL of the following fields.

Return ONLY a valid JSON object with exactly these keys (use null if a field is not found):

{
  "vendor_name": "string",
  "vendor_address": "string",
  "vendor_email": "string",
  "vendor_phone": "string",
  "invoice_number": "string",
  "invoice_date": "YYYY-MM-DD or null",
  "due_date": "YYYY-MM-DD or null",
  "po_number": "string or null",
  "currency": "USD/EUR/INR/etc",
  "subtotal": number or null,
  "tax_amount": number or null,
  "tax_rate": number or null,
  "discount": number or null,
  "total_amount": number or null,
  "payment_terms": "string or null",
  "line_items": [
    {
      "description": "string",
      "quantity": number or null,
      "unit_price": number or null,
      "amount": number or null
    }
  ],
  "notes": "string or null",
  "confidence_score": number between 0 and 1
}

Rules:
- All monetary values must be plain numbers (no currency symbols, no commas)
- Dates must be in YYYY-MM-DD format or null
- confidence_score reflects how clearly readable the invoice was
- Return ONLY the JSON object, no markdown, no explanation
"""


def extract_invoice(file_bytes: bytes, filename: str) -> dict:
    """
    Main extraction function.
    Accepts raw file bytes (PDF or image) and returns extracted fields.
    """
    model = get_gemini_client(vision=True)

    # Convert to image for Gemini Vision
    image = _prepare_image(file_bytes, filename)

    try:
        response = model.generate_content([EXTRACTION_PROMPT, image])
        raw = response.text.strip()

        # Strip markdown code fences if present
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)

        data = json.loads(raw)
        data["_source_file"] = filename
        data["_agent"] = "ocr-extraction"
        return {"success": True, "data": data}

    except json.JSONDecodeError as e:
        return {
            "success": False,
            "error": f"Gemini returned non-JSON output: {str(e)}",
            "raw_response": response.text[:500],
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def _prepare_image(file_bytes: bytes, filename: str) -> Image.Image:
    """Convert PDF first page or image bytes to PIL Image."""
    ext = filename.lower().split(".")[-1]

    if ext == "pdf":
        try:
            import PyPDF2
            # For PDFs, extract text and use text-based extraction
            # (Gemini Flash handles PDF bytes directly too)
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            # Try to get embedded images or use the PDF bytes directly
            # Gemini 1.5 Flash can handle PDF as base64
            return _pdf_to_image_fallback(file_bytes)
        except Exception:
            return _pdf_to_image_fallback(file_bytes)

    # For images (jpg, png, tiff, webp)
    return Image.open(io.BytesIO(file_bytes))


def _pdf_to_image_fallback(pdf_bytes: bytes) -> Image.Image:
    """
    Fallback: wrap PDF bytes as a PIL-compatible object via base64.
    Gemini 1.5 Flash accepts PDF bytes natively via the parts API,
    but for simplicity we pass it as an image blob here.
    If you install pdf2image + poppler you get true page rendering.
    """
    try:
        from pdf2image import convert_from_bytes
        pages = convert_from_bytes(pdf_bytes, first_page=1, last_page=1)
        return pages[0]
    except ImportError:
        # pdf2image not installed — create a placeholder and warn
        img = Image.new("RGB", (800, 600), color=(255, 255, 255))
        return img


async def extract_invoice_with_text_fallback(file_bytes: bytes, filename: str) -> dict:
    """
    Alternative: send PDF as base64 blob directly to Gemini
    using the native file parts API (works best for text-heavy PDFs).
    """
    model = get_gemini_client(vision=True)
    ext = filename.lower().split(".")[-1]

    if ext == "pdf":
        # Gemini 1.5 Flash supports inline PDF via base64
        b64 = base64.b64encode(file_bytes).decode()
        parts = [
            {"inline_data": {"mime_type": "application/pdf", "data": b64}},
            EXTRACTION_PROMPT,
        ]
    else:
        image = Image.open(io.BytesIO(file_bytes))
        parts = [EXTRACTION_PROMPT, image]

    try:
        response = model.generate_content(parts)
        raw = response.text.strip()
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
        data = json.loads(raw)
        data["_source_file"] = filename
        data["_agent"] = "ocr-extraction-text"
        return {"success": True, "data": data}
    except Exception as e:
        return {"success": False, "error": str(e)}
