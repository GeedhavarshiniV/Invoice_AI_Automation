"""
Chatbot Agent
-------------
Conversational AI assistant for invoice Q&A.
Maintains conversation history per session.
Uses Gemini with a structured system prompt that includes invoice context.
"""

import json
import re
from core.gemini import get_gemini_client

# In-memory session store  { session_id: [{"role": ..., "parts": [...]}] }
_sessions: dict[str, list] = {}

SYSTEM_PROMPT = """You are InvoiceAI Assistant — a helpful, precise financial assistant embedded in an invoice management platform.

You help finance teams by:
- Answering questions about specific invoices
- Summarising spending by vendor, category, or time period
- Flagging anomalies or overdue invoices
- Drafting professional payment reminder emails
- Explaining validation errors in plain language
- Advising on payment terms and invoice best practices

Current invoice context (live data passed per request):
{context}

Rules:
- Be concise and direct. Finance people are busy.
- Use numbers precisely. Don't approximate unless data is missing.
- Format lists and tables clearly using plain text.
- If you draft an email, make it professional and ready to send.
- If data is missing, say so clearly rather than guessing.
- Never make up invoice numbers, amounts, or vendor names.
"""


def chat(session_id: str, user_message: str, invoice_context: dict = None) -> dict:
    """
    Send a message and get a response.
    Maintains multi-turn conversation history per session_id.
    """
    model = get_gemini_client()

    # Build context string
    context_str = json.dumps(invoice_context, indent=2) if invoice_context else "No specific invoice context provided. Answer based on general invoice knowledge."

    # Initialise session with system prompt as first user/model exchange
    if session_id not in _sessions:
        _sessions[session_id] = []

    history = _sessions[session_id]

    # Start a chat with history
    chat_session = model.start_chat(history=history)

    # Inject system context into first message if session is new
    if not history:
        prefixed = f"{SYSTEM_PROMPT.format(context=context_str)}\n\nUser: {user_message}"
    else:
        prefixed = user_message

    try:
        response = chat_session.send_message(prefixed)
        reply = response.text.strip()

        # Save to session history
        _sessions[session_id] = chat_session.history

        return {
            "success": True,
            "reply": reply,
            "session_id": session_id,
            "turn": len(_sessions[session_id]) // 2,
            "_agent": "chatbot",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def clear_session(session_id: str) -> bool:
    """Clear conversation history for a session."""
    if session_id in _sessions:
        del _sessions[session_id]
        return True
    return False


def list_sessions() -> list[str]:
    return list(_sessions.keys())
