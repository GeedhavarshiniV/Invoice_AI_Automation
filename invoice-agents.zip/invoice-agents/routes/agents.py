"""
API Routes
----------
All three agent endpoints wired into FastAPI.
"""

from fastapi import APIRouter, UploadFile, File, HTTPException, Body
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
import uuid

from agents.ocr_agent import extract_invoice, extract_invoice_with_text_fallback
from agents.validation_agent import validate_invoice, ai_validate_invoice
from agents.chatbot_agent import chat, clear_session, list_sessions

router = APIRouter()

ALLOWED_TYPES = {
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/tiff",
    "image/webp",
}

# ── OCR EXTRACTION ──────────────────────────────────────────────────────────

@router.post("/extract", summary="Extract invoice data from a file")
async def extract(file: UploadFile = File(...)):
    """
    Upload a PDF or image invoice.
    Returns structured JSON with all extracted fields.
    """
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type: {file.content_type}. Allowed: PDF, JPG, PNG, TIFF, WEBP"
        )

    file_bytes = await file.read()

    if len(file_bytes) > 25 * 1024 * 1024:  # 25MB limit
        raise HTTPException(status_code=413, detail="File too large. Max 25MB.")

    # Try native PDF extraction first, fall back to image
    if file.content_type == "application/pdf":
        result = await extract_invoice_with_text_fallback(file_bytes, file.filename)
    else:
        result = extract_invoice(file_bytes, file.filename)

    if not result["success"]:
        raise HTTPException(status_code=422, detail=result["error"])

    return JSONResponse(content=result)


# ── VALIDATION ──────────────────────────────────────────────────────────────

@router.post("/validate", summary="Validate extracted invoice data")
async def validate(invoice_data: dict = Body(...)):
    """
    Pass extracted invoice data (from /extract).
    Returns rule-based validation results.
    """
    if not invoice_data:
        raise HTTPException(status_code=400, detail="Invoice data is required")

    rule_result = validate_invoice(invoice_data)
    return JSONResponse(content=rule_result)


@router.post("/validate/ai", summary="AI anomaly detection on invoice data")
async def validate_ai(invoice_data: dict = Body(...)):
    """
    Runs Gemini-powered anomaly detection on invoice data.
    Returns risk score, anomalies, and recommendation.
    """
    result = ai_validate_invoice(invoice_data)
    if not result["success"]:
        raise HTTPException(status_code=422, detail=result["error"])
    return JSONResponse(content=result)


@router.post("/validate/full", summary="Extract + validate in one call")
async def validate_full(file: UploadFile = File(...)):
    """
    Convenience endpoint: upload a file, get extraction + full validation in one response.
    """
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=415, detail=f"Unsupported file type: {file.content_type}")

    file_bytes = await file.read()

    # Step 1: Extract
    if file.content_type == "application/pdf":
        extraction = await extract_invoice_with_text_fallback(file_bytes, file.filename)
    else:
        extraction = extract_invoice(file_bytes, file.filename)

    if not extraction["success"]:
        raise HTTPException(status_code=422, detail=f"Extraction failed: {extraction['error']}")

    invoice_data = extraction["data"]

    # Step 2: Rule validation
    rules = validate_invoice(invoice_data)

    # Step 3: AI validation
    ai = ai_validate_invoice(invoice_data)

    return JSONResponse(content={
        "extraction": invoice_data,
        "rule_validation": rules,
        "ai_validation": ai.get("data") if ai["success"] else {"error": ai["error"]},
        "pipeline": "extract → validate-rules → validate-ai",
    })


# ── CHATBOT ─────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    invoice_context: Optional[dict] = None  # Pass invoice data for context-aware answers


@router.post("/chat", summary="Chat with the invoice AI assistant")
async def chat_endpoint(req: ChatRequest):
    """
    Send a message to the invoice AI assistant.
    Optionally pass invoice_context to make answers invoice-specific.
    Maintains conversation history per session_id.
    """
    session_id = req.session_id or str(uuid.uuid4())

    result = chat(
        session_id=session_id,
        user_message=req.message,
        invoice_context=req.invoice_context,
    )

    if not result["success"]:
        raise HTTPException(status_code=422, detail=result["error"])

    return JSONResponse(content=result)


@router.delete("/chat/{session_id}", summary="Clear chat history for a session")
async def clear_chat(session_id: str):
    cleared = clear_session(session_id)
    return {"cleared": cleared, "session_id": session_id}


@router.get("/chat/sessions", summary="List active chat sessions")
async def get_sessions():
    return {"sessions": list_sessions()}


# ── HEALTH ──────────────────────────────────────────────────────────────────

@router.get("/health", summary="Health check")
async def health():
    import os
    key_set = bool(os.getenv("GEMINI_API_KEY"))
    return {
        "status": "ok",
        "gemini_key_configured": key_set,
        "agents": ["ocr-extraction", "validation-rules", "validation-ai", "chatbot"],
    }
